﻿import Game_FrameWork
import Logo_State

from pico2d import *

Game_FrameWork.run(Logo_State)

close_canvas()
